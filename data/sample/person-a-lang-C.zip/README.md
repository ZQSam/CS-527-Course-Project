# Person A baseline dataset for C

This profile contains accepted coverage/rankings, buggy-source snapshots, model
inputs, successful-bug lists, and original failure/provenance evidence.
Code is supplied by the GitHub repository, not duplicated inside this ZIP.

From the repository root, run:

```bash
python3 scripts/prepare_sample.py --profile C
```

Then read `.work/sample/C/index.json`. Its paths are relative to this profile.
For source identity validation, install the pinned parser outside this profile:

```bash
python3 scripts/setup_python.py
PYTHONPATH="$PWD/.deps" python3 scripts/prepare_sample.py --profile C --check-source
```

See `docs/person_a_handoff_c.md` in the repository for the handoff and evaluation
instructions. Source snapshots are not complete buildable checkouts. No patch
labels or Top-k/MRR results are supplied. Operational failures are distinct from
pending methodological exclusion review.
