# Milestone 2: Person A coverage and baseline ranking

Run: `20261021T035617823403Z`

Coverage and SBFL outputs only. Patch labels and Top-k/MRR evaluation belong to Person C.

| Bug | Status | Passing | Failing | Zero-hit completed tests | Parsed methods | GZoltar Ochiai check |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Lang-1 | complete | 2290 | 1 | 19 | 2403 | matched |
| Lang-3 | complete | 2285 | 1 | 19 | 2396 | matched |
| Lang-4 | complete | 2284 | 1 | 19 | 2393 | matched |

## Lang-1

- [Execution/provenance record](runs/20261021T035617823403Z/Lang-1/result.json)
- [Normalized per-test coverage](../../data/coverage/20261021T035617823403Z/Lang-1/coverage.json)
- [Complete Ochiai ranking](../../data/sbfl/20261021T035617823403Z/Lang-1/ochiai.csv)
- [Complete DStar ranking](../../data/sbfl/20261021T035617823403Z/Lang-1/dstar.csv)
- [Top candidates with buggy source](../../data/sbfl/20261021T035617823403Z/Lang-1/top20.json)
- [Mapping and reference checks](runs/20261021T035617823403Z/Lang-1/validation.json)

## Lang-3

- [Execution/provenance record](runs/20261021T035617823403Z/Lang-3/result.json)
- [Normalized per-test coverage](../../data/coverage/20261021T035617823403Z/Lang-3/coverage.json)
- [Complete Ochiai ranking](../../data/sbfl/20261021T035617823403Z/Lang-3/ochiai.csv)
- [Complete DStar ranking](../../data/sbfl/20261021T035617823403Z/Lang-3/dstar.csv)
- [Top candidates with buggy source](../../data/sbfl/20261021T035617823403Z/Lang-3/top20.json)
- [Mapping and reference checks](runs/20261021T035617823403Z/Lang-3/validation.json)

## Lang-4

- [Execution/provenance record](runs/20261021T035617823403Z/Lang-4/result.json)
- [Normalized per-test coverage](../../data/coverage/20261021T035617823403Z/Lang-4/coverage.json)
- [Complete Ochiai ranking](../../data/sbfl/20261021T035617823403Z/Lang-4/ochiai.csv)
- [Complete DStar ranking](../../data/sbfl/20261021T035617823403Z/Lang-4/dstar.csv)
- [Top candidates with buggy source](../../data/sbfl/20261021T035617823403Z/Lang-4/top20.json)
- [Mapping and reference checks](runs/20261021T035617823403Z/Lang-4/validation.json)

## Interpretation

- The test cohort comes from a validated Defects4J full-suite run. Discovery-only tests are recorded, not added.
- Explicit completion logs account for zero-hit tests omitted by GZoltar's CSV. No missing outcome is assumed to pass.
- Each physical source line uses the OR of its spectrum columns per test. A method receives its maximum line score.
- Concrete production methods/constructors with no recorded hits remain in the full ranking with score zero.
- Equal scores retain rank_min/rank_max and tie_size. method_id only stabilizes their displayed order.
- DStar uses exponent 2. Its infinite scores are the JSON string Infinity, not a nonstandard JSON number.
- Source initializers and implicit/compiler-generated members without a declared method are retained in mapping diagnostics.
- No patch labels, fixed code, or model requests are used. No Top-k accuracy or MRR is claimed.

## Preserved development failures

- [20261021T034928236241Z](runs/20261021T034928236241Z/summary.json): Lang-1 at source-index: ValueError: Duplicate method IDs in src/main/java/org/apache/commons/lang3/Validate.java
- [20261021T034953153286Z](runs/20261021T034953153286Z/summary.json): Lang-1 at source-index: ValueError: Duplicate method IDs in src/main/java/org/apache/commons/lang3/Validate.java: ['src/main/java/org/apache/commons/lang3/Validate.java::org.apache.commons.lang3.Validate#notEmpty(T,String,Object[])', 'src/main/java/org/apache/commons/lang3/Validate.java::org.apache.commons.lang3.Validate#notEmpty(T)', 'src/main/java/org/apache/commons/lang3/Validate.java::org.apache.commons.lang3.Validate#validIndex(T,int,String,Object[])', 'src/main/java/org/apache/commons/lang3/Validate.java::org.apache.commons.lang3.Validate#validIndex(T,int)']
- [20261021T035113438856Z](runs/20261021T035113438856Z/summary.json): Lang-1 at coverage: ValueError: Malformed GZoltar statement: org.apache.commons.lang3$AnnotationUtils#equals(java.lang.annotation.Annotation
- [20261021T035324285528Z](runs/20261021T035324285528Z/summary.json): Lang-1 at sbfl-and-validation: ValueError: Unexplained source mapping failure: org.apache.commons.lang3.builder$ToStringStyle$DefaultToStringStyle#ToStringStyle$DefaultToStringStyle():2127

[Artifact integrity audit](artifact-audit.json) checks compressed raw replay, rankings, candidate source, and unchanged source/class hashes.
