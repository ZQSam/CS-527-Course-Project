# Milestone 1: execution evidence

Run: `20261021T032719068123Z`

This checks checkout, compile, and failure reproduction. No coverage or fault-localization result is claimed.

| Bug | Outcome | Full-suite failing tests | Expected trigger tests | Isolated triggers reproduced |
| --- | --- | ---: | ---: | ---: |
| Lang-1 | reproduced | 1 | 1 | 1 |
| Lang-3 | reproduced | 1 | 1 | 1 |
| Lang-4 | reproduced | 1 | 1 | 1 |

## Lang-1

- [Outcome and source revision](runs/20261021T032719068123Z/Lang-1/result.json)
- [Compile log](runs/20261021T032719068123Z/Lang-1/compile.stderr.log)
- [Full-suite output](runs/20261021T032719068123Z/Lang-1/test-full.stdout.log)
- [Full-suite stack traces](runs/20261021T032719068123Z/Lang-1/test-full.failing_tests.txt)
- Trigger: `org.apache.commons.lang3.math.NumberUtilsTest::TestLang747`; [isolated run](runs/20261021T032719068123Z/Lang-1/test-trigger-001.stdout.log)

## Lang-3

- [Outcome and source revision](runs/20261021T032719068123Z/Lang-3/result.json)
- [Compile log](runs/20261021T032719068123Z/Lang-3/compile.stderr.log)
- [Full-suite output](runs/20261021T032719068123Z/Lang-3/test-full.stdout.log)
- [Full-suite stack traces](runs/20261021T032719068123Z/Lang-3/test-full.failing_tests.txt)
- Trigger: `org.apache.commons.lang3.math.NumberUtilsTest::testStringCreateNumberEnsureNoPrecisionLoss`; [isolated run](runs/20261021T032719068123Z/Lang-3/test-trigger-001.stdout.log)

## Lang-4

- [Outcome and source revision](runs/20261021T032719068123Z/Lang-4/result.json)
- [Compile log](runs/20261021T032719068123Z/Lang-4/compile.stderr.log)
- [Full-suite output](runs/20261021T032719068123Z/Lang-4/test-full.stdout.log)
- [Full-suite stack traces](runs/20261021T032719068123Z/Lang-4/test-full.failing_tests.txt)
- Trigger: `org.apache.commons.lang3.text.translate.LookupTranslatorTest::testLang882`; [isolated run](runs/20261021T032719068123Z/Lang-4/test-trigger-001.stdout.log)

## Environment

- [Observed tool versions, artifact hashes, and Java properties](../environment/versions.json)
- [Resolved Docker image](../environment/image-inspect.json)
- [Offline unit-test output](../tests/unit-tests.log)

## Previous failed attempts

- [20261021T032518352329Z](runs/20261021T032518352329Z/summary.json): Lang-1 at full-test: Expected triggers ['org.apache.commons.lang3.math.NumberUtilsTest::TestLang747'], observed failures ['org.apache.commons.lang3.SystemUtilsTest::testGetUserHome', 'org.apache.commons.lang3.math.NumberUtilsTest::TestLang747']; Lang-3 at full-test: Expected triggers ['org.apache.commons.lang3.math.NumberUtilsTest::testStringCreateNumberEnsureNoPrecisionLoss'], observed failures ['org.apache.commons.lang3.SystemUtilsTest::testGetUserHome', 'org.apache.commons.lang3.math.NumberUtilsTest::testStringCreateNumberEnsureNoPrecisionLoss']; Lang-4 at full-test: Expected triggers ['org.apache.commons.lang3.text.translate.LookupTranslatorTest::testLang882'], observed failures ['org.apache.commons.lang3.SystemUtilsTest::testGetUserHome', 'org.apache.commons.lang3.text.translate.LookupTranslatorTest::testLang882']

The initial container's missing passwd entry made Java's `user.home` equal `?`, introducing an unrelated Lang test failure.
[Java settings before the fix](../environment/user-properties.before-fix.log) preserve the evidence.
The container now defines a real user/home; no benchmark test was removed or changed to hide that failure.
