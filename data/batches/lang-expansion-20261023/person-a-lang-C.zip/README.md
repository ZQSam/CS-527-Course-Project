# C batch data

Read index.json; paths are relative to this profile.
cohort.json was frozen before collection. status.json includes every requested bug.
Use the repository's scripts/prepare_sample.py --release <batch release.json> --profile C.
The old three-case C adapter is pinned to the pilot and must be extended by C for this batch.
Source snapshots are for label mapping, not complete buildable checkouts.
